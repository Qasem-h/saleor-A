export { View as CollectionPage } from "./View";
