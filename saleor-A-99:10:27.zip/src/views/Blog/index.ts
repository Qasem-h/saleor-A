export { default as BlogPage } from "./View";
