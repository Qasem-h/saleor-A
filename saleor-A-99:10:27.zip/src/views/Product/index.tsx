export { default as ProductPage } from "./View";
