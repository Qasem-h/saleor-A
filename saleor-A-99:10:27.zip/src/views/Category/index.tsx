export { default as CategoryPage } from "./View";
