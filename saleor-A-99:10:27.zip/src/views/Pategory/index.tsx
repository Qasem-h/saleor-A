export { default as PategoryPage } from "./View";
