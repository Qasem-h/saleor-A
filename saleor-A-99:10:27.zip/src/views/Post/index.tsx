export { default as PostPage } from "./View";
