import { PostDetails_post } from "./gqlTypes/PostDetails";

export interface IProps {
  post: PostDetails_post;
}
