export { default as HomePage } from "./View";
