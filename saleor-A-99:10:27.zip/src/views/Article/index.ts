export { default as ArticlePage } from "./View";
