export { default as SearchPage } from "./View";
