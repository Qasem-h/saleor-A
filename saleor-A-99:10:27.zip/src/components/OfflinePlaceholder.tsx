import * as React from "react";

const OfflinePlaceholder: React.FC<{}> = () => <>OFFLINE :(</>;

export default OfflinePlaceholder;
