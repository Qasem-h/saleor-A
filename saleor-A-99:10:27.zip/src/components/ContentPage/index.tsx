import * as React from "react";

import "./scss/index.scss";

const ContentPage: React.FC = () => <div>Content Page</div>;

export default ContentPage;
