export interface IFormError {
  message: string;
  field?: string;
}
