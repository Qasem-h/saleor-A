export interface ICheckoutStep {
  index: number;
  link: string;
  name: string;
}
