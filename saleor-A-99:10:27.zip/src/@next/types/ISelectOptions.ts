export interface ISelectOption {
  label: string;
  value: string;
}
