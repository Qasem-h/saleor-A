export interface IPostFilters {
  pageSize: number;
}
