import { IProduct } from "@types";

export interface IProps {
  product: IProduct;
}
