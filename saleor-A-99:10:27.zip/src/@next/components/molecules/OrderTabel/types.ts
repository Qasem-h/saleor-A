import * as H from "history";

export interface IProps {
  orders?: any[];
  history: H.History;
}
