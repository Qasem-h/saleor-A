import { IAddress } from "@types";

export interface IProps {
  address?: IAddress | null;
  email?: string;
}
