import { IPost } from "@types";

export interface IProps {
  post: IPost;
}
