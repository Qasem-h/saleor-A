import { storiesOf } from "@storybook/react";
import React from "react";

import { PostTile } from ".";
import { POST } from "./fixtures";

storiesOf("@components/molecules/PostTile", module)
  .addParameters({ component: PostTile })
  .add("default", () => (
    <div style={{ width: "400px" }}>
      <PostTile post={POST} />
    </div>
  ));
