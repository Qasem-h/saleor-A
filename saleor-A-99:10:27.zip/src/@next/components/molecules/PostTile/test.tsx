import { shallow } from "enzyme";
import "jest-styled-components";
import React from "react";

import { PostTile } from ".";
import { POST } from "./fixtures";

describe("<PostTile />", () => {
  it("exists", () => {
    const wrapper = shallow(<PostTile post={POST} />);

    expect(wrapper.exists()).toEqual(true);
  });
  it("has post title", () => {
    const wrapper = shallow(<PostTile post={POST} />);

    expect(wrapper.text()).toContain(POST.title);
  });
});
