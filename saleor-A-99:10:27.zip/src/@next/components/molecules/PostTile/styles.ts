import { media, styled } from "@styles";
import { css } from "styled-components";

const textProps = css`
  font-size: ${props => props.theme.typography.baseFontSize};
  margin: 0 0 0.5rem 0;
  text-align: left;
`;

export const ListItem = styled.div`
  padding-right: 0;
  padding-bottom: 40px;
`;

export const Body = styled.div`
    width: 60%;
    padding: 0;
    padding-left: 30px;
    height: auto;
    background: none;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-flow: row wrap;
    flex-flow: row wrap;
`;


export const Wrapper = styled.div`
  background: ${props => props.theme.colors.light};
  overflow: hidden;
  margin-right: auto;
  margin-left: auto;
  border-radius: 10px;
  box-shadow: 0 1px 10px 10px rgba(0,0,0,.05);

  :hover {
    background-color: ${props => props.theme.colors.hoverLightBackground};
  }

  ${media.largeScreen`
    padding: 1.8rem;
  `}
`;

export const Title = styled.h4`
font-size: var(--fs_item);
    color: var(--color_item);
    line-height: 1.55em;
    font-weight: 100;
    display: block;
  font-weight: normal;
  ${textProps}
`;

export const Content = styled.div`
    font-size: 13px;
    line-height: 1.9em;
`;

export const Image = styled.div`
  float: left;
  width: auto;
  height: auto;
  max-width: 100%;

  > img {
    width: auto;
    height: auto;
    max-width: 100%;
  }
`;
