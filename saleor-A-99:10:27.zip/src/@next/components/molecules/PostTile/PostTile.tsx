import React from "react";

import { Thumbnail } from "@components/molecules";

import * as S from "./styles";
import { IProps } from "./types";

export const PostTile: React.FC<IProps> = ({ post }: IProps) => {

  return (
    <S.ListItem>
    <S.Wrapper>
      <S.Image data-test="postThumbnail">
        <Thumbnail source={post} />
      </S.Image>
      <S.Body>
      <S.Title data-test="postTile">{post.title}</S.Title>
      <S.Content data-test="postTile">{post.title}</S.Content>
      </S.Body>
    </S.Wrapper>
  </S.ListItem>

  );
};
