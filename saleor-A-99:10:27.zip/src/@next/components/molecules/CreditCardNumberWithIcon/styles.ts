import { styled } from "@styles";

export const Wrapper = styled.span`
  padding: 0 1rem;
`;
