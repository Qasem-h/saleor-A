export * from "./ThankYouPage";
