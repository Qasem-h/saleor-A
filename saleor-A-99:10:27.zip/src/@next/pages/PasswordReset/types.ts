import { History } from "history";

export interface IProps {
  history: History;
}

export interface FormikProps {
  password: string;
  retypedPassword: string;
}
