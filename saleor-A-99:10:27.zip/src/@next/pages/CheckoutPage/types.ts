import * as H from "history";

export interface IProps {
  history: H.History;
}
