export interface FormError {
  message: string;
  field?: string;
}
