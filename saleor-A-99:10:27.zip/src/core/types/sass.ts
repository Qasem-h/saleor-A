declare module ".*/scss/variables.scss" {
  const content: {
    mediumScreen: string;
    smallScreen: string;
  };
  export = content;
}
