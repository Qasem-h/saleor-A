export { default as OrderDetails } from "./OrderDetails/View";
